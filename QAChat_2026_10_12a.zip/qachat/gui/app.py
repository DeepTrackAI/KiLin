"""Create and run QAChat's Qt desktop application.

``main`` imports the optional Qt components, builds the main window, and runs
the application event loop. Missing GUI dependencies produce an explanatory
message and a nonzero return code rather than triggering installation. The
window module owns communication with the separate engine process.

Key Features
------------

- **Lazy Qt imports**

    Keep optional GUI imports inside the application startup path.

- **Explicit event loop**

    Return the Qt application exit status to a command-line entry point.

Module Structure
----------------

- ``main``

    Start the desktop window, or explain how to install Qt.

Examples
--------
>>> import qachat.gui.app
>>> exit_code = qachat.gui.app.main(["qachat"])

This example opens a desktop window and returns after the application exits.

"""

from __future__ import annotations

from collections.abc import Sequence
import sys

__all__ = [
    "main",
]


def main(arguments: Sequence[str] | None = None) -> int:
    """Start the desktop window, or explain how to install Qt.

    Parameters
    ----------
    arguments: Sequence[str] | None, optional
        Arguments passed to Qt. None uses the process command line. Defaults to
        ``None``.

    Returns
    -------
    int
        Qt's exit code, or one when the GUI dependency is missing.

    """

    try:
        from PySide6.QtWidgets import QApplication

        from qachat.gui.window import ChatWindow
    except ImportError as error:
        print(
            f"GUI dependency missing: {error}. Install with "
            "uv sync --extra gui --extra mlx (or --extra torch).",
            file=sys.stderr,
        )
        return 1

    app = QApplication(list(arguments) if arguments is not None else sys.argv)
    app.setApplicationName("QAChat")
    window = ChatWindow()
    window.show()
    return app.exec()
